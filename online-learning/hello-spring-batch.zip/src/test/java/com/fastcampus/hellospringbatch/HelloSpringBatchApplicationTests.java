package com.fastcampus.hellospringbatch;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HelloSpringBatchApplicationTests {

	@Test
	void contextLoads() {
	}

}
